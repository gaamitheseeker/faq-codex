import { IFAQ } from '../models/IFAQ';

/** Filters an already-loaded FAQ collection. No network request is made here. */
export const filterFAQs = (faqs: readonly IFAQ[], searchTerm: string): IFAQ[] => {
  const normalizedTerm = searchTerm.trim().toLocaleLowerCase();

  if (!normalizedTerm) {
    return faqs.slice();
  }

  return faqs.filter((faq: IFAQ) =>
    faq.question.toLocaleLowerCase().indexOf(normalizedTerm) !== -1
  );
};
