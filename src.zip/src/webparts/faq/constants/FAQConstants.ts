export const DEFAULT_FAQ_LIST_NAME = 'FAQ';
export const FAQ_TITLE = 'Frequently Asked Questions';
export const FAQ_SEARCH_PLACEHOLDER = 'Search frequently asked questions...';

/** SharePoint internal names belong only in the data-access layer. */
export const FAQ_FIELDS = {
  id: 'Id',
  question: 'Title',
  answer: '_x8cea_x554f_'
} as const;
