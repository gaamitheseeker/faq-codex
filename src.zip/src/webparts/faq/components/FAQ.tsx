import * as React from 'react';
import { WebPartContext } from '@microsoft/sp-webpart-base';

import { FAQ_SEARCH_PLACEHOLDER, FAQ_TITLE } from '../constants/FAQConstants';
import { useFAQs } from '../hooks/useFAQs';
import { FAQService } from '../services/FAQService';
import styles from '../styles/FAQ.module.scss';
import { filterFAQs } from '../utils/FAQUtils';
import { EmptyState } from './EmptyState';
import { ErrorState } from './ErrorState';
import { FAQList } from './FAQList';
import { FAQSearch } from './FAQSearch';
import { Loading } from './Loading';

export interface IFAQProps {
  context: WebPartContext;
  listName: string;
}

export const FAQ: React.FC<IFAQProps> = ({ context, listName }) => {
  const [searchTerm, setSearchTerm] = React.useState<string>('');
  const service = React.useMemo(() => new FAQService(context, listName), [context, listName]);
  const { faqs, loading, error, reload } = useFAQs(service);
  const filteredFAQs = React.useMemo(
    () => filterFAQs(faqs, searchTerm),
    [faqs, searchTerm]
  );

  return (
    <section className={styles.faq} aria-labelledby="faq-heading">
      <h2 id="faq-heading" className={styles.title}>{FAQ_TITLE}</h2>
      {loading && <Loading />}
      {!loading && error && <ErrorState onRetry={() => { void reload(); }} />}
      {!loading && !error && faqs.length === 0 && <EmptyState />}
      {!loading && !error && faqs.length > 0 && (
        <>
          <FAQSearch value={searchTerm} placeholder={FAQ_SEARCH_PLACEHOLDER} onChange={setSearchTerm} />
          <FAQList faqs={filteredFAQs} searchTerm={searchTerm} />
        </>
      )}
    </section>
  );
};
