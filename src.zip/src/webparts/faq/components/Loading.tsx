import * as React from 'react';
import styles from '../styles/FAQ.module.scss';

export const Loading: React.FC = () => (
  <div className={styles.status} role="status" aria-live="polite">Loading FAQs...</div>
);
