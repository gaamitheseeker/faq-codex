import * as React from 'react';
import { IFAQ } from '../models/IFAQ';
import styles from '../styles/FAQ.module.scss';
import { FAQItem } from './FAQItem';

export interface IFAQListProps {
  faqs: readonly IFAQ[];
  searchTerm: string;
}

export const FAQList: React.FC<IFAQListProps> = ({ faqs, searchTerm }) => {
  if (faqs.length === 0) {
    return <p className={styles.status}>No FAQs found for &quot;{searchTerm.trim()}&quot;.</p>;
  }

  return (
    <div className={styles.faqList}>
      {faqs.map((faq: IFAQ) => <FAQItem key={faq.id} faq={faq} />)}
    </div>
  );
};
