import * as React from 'react';
import { IFAQ } from '../models/IFAQ';
import styles from '../styles/FAQ.module.scss';

export interface IFAQItemProps {
  faq: IFAQ;
}

export const FAQItem: React.FC<IFAQItemProps> = ({ faq }) => {
  const [isExpanded, setIsExpanded] = React.useState<boolean>(false);
  const answerId = `faq-answer-${faq.id}`;

  return (
    <article className={styles.faqItem}>
      <h3 className={styles.questionHeading}>
        <button
          type="button"
          className={styles.questionButton}
          aria-expanded={isExpanded}
          aria-controls={answerId}
          onClick={() => setIsExpanded((current: boolean) => !current)}
        >
          <span>{faq.question}</span>
          <span className={styles.chevron} aria-hidden="true">{isExpanded ? '⌄' : '›'}</span>
        </button>
      </h3>
      {isExpanded && (
        <div id={answerId} className={styles.answer} role="region" aria-label={`Answer: ${faq.question}`}>
          {faq.answer}
        </div>
      )}
    </article>
  );
};
