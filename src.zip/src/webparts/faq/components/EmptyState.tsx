import * as React from 'react';
import styles from '../styles/FAQ.module.scss';

export const EmptyState: React.FC = () => (
  <p className={styles.status}>No frequently asked questions are available.</p>
);
