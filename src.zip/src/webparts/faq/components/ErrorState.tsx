import * as React from 'react';
import styles from '../styles/FAQ.module.scss';

export interface IErrorStateProps {
  onRetry: () => void;
}

export const ErrorState: React.FC<IErrorStateProps> = ({ onRetry }) => (
  <div className={styles.errorState} role="alert">
    <p>Unable to load FAQs. Please try again later.</p>
    <button className={styles.retryButton} type="button" onClick={onRetry}>Try again</button>
  </div>
);
