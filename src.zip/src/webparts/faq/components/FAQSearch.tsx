import * as React from 'react';
import styles from '../styles/FAQ.module.scss';

let searchInputSequence = 0;

export interface IFAQSearchProps {
  value: string;
  placeholder: string;
  onChange: (value: string) => void;
}

export const FAQSearch: React.FC<IFAQSearchProps> = ({ value, placeholder, onChange }) => {
  // React 17 (the SPFx 1.21.1 runtime) does not provide React.useId.
  const inputId = React.useRef<string>(`faq-search-${++searchInputSequence}`).current;

  return (
    <div className={styles.searchWrapper}>
      <label className={styles.screenReaderOnly} htmlFor={inputId}>Search FAQs</label>
      <span className={styles.searchIcon} aria-hidden="true">⌕</span>
      <input
        id={inputId}
        className={styles.searchInput}
        type="search"
        value={value}
        placeholder={placeholder}
        onChange={(event: React.ChangeEvent<HTMLInputElement>) => onChange(event.target.value)}
      />
      {value && (
        <button
          type="button"
          className={styles.clearButton}
          aria-label="Clear FAQ search"
          onClick={() => onChange('')}
        >
          Clear
        </button>
      )}
    </div>
  );
};
