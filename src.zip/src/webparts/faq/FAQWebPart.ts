import * as React from 'react';
import * as ReactDom from 'react-dom';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IPropertyPaneConfiguration, PropertyPaneTextField } from '@microsoft/sp-property-pane';

import { FAQ } from './components/FAQ';
import { DEFAULT_FAQ_LIST_NAME } from './constants/FAQConstants';

export interface IFAQWebPartProps {
  faqListName: string;
}

export default class FAQWebPart extends BaseClientSideWebPart<IFAQWebPartProps> {
  public render(): void {
    const element: React.ReactElement = React.createElement(FAQ, {
      context: this.context,
      listName: this.properties.faqListName || DEFAULT_FAQ_LIST_NAME
    });

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [{
        header: { description: 'Configure the FAQ data source.' },
        groups: [{
          groupName: 'FAQ settings',
          groupFields: [
            PropertyPaneTextField('faqListName', {
              label: 'FAQ List Name',
              value: DEFAULT_FAQ_LIST_NAME
            })
          ]
        }]
      }]
    };
  }
}
