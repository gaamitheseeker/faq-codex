/** Backend-agnostic FAQ model consumed by React components. */
export interface IFAQ {
  id: number;
  question: string;
  answer: string;
}
