import { useCallback, useEffect, useState } from 'react';

import { IFAQ } from '../models/IFAQ';
import { FAQService } from '../services/FAQService';

export interface IUseFAQsResult {
  faqs: IFAQ[];
  loading: boolean;
  error: boolean;
  reload: () => Promise<void>;
}

export const useFAQs = (faqService: FAQService): IUseFAQsResult => {
  const [faqs, setFaqs] = useState<IFAQ[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<boolean>(false);

  const reload = useCallback(async (): Promise<void> => {
    setLoading(true);
    setError(false);

    try {
      setFaqs(await faqService.getFAQs());
    } catch (fetchError) {
      setFaqs([]);
      setError(true);
    } finally {
      setLoading(false);
    }
  }, [faqService]);

  useEffect(() => {
    void reload();
  }, [reload]);

  return { faqs, loading, error, reload };
};
