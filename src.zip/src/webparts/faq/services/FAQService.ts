import { SPFI, spfi, SPFx } from '@pnp/sp';
import '@pnp/sp/webs';
import '@pnp/sp/lists';
import '@pnp/sp/items';
import { WebPartContext } from '@microsoft/sp-webpart-base';

import { FAQ_FIELDS } from '../constants/FAQConstants';
import { IFAQ } from '../models/IFAQ';

interface ISharePointFAQItem {
  Id: number;
  Title: string;
  _x8cea_x554f_: string;
}

/** Isolates SharePoint/PnPjs details from the React UI. */
export class FAQService {
  private readonly sp: SPFI;

  public constructor(
    context: WebPartContext,
    private readonly listName: string
  ) {
    this.sp = spfi().using(SPFx(context));
  }

  public async getFAQs(): Promise<IFAQ[]> {
    const trimmedListName = this.listName.trim();
    if (!trimmedListName) {
      throw new Error('An FAQ list name is required.');
    }

    try {
      const items: ISharePointFAQItem[] = await this.sp.web.lists
        .getByTitle(trimmedListName)
        .items
        .select(FAQ_FIELDS.id, FAQ_FIELDS.question, FAQ_FIELDS.answer)
        .orderBy(FAQ_FIELDS.question, true)();

      return items.map((item: ISharePointFAQItem): IFAQ => ({
        id: item.Id,
        question: item.Title || '',
        answer: item._x8cea_x554f_ || ''
      }));
    } catch (error) {
      // Log diagnostics for developers; callers deliberately receive a safe error.
      // eslint-disable-next-line no-console
      console.error('FAQService: unable to retrieve FAQ items.', error);
      throw new Error('Unable to retrieve FAQs.');
    }
  }
}
